UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/c03889408_390x286.jpg' WHERE DESCRIPTION = 'HP laptop' AND PRIORITY = 1;
UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/c03889585_390x286.jpg' WHERE DESCRIPTION = 'HP laptop' AND PRIORITY = 2;
UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/c03889529_390x286.jpg' WHERE DESCRIPTION = 'HP laptop' AND PRIORITY = 3;
UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/c03889425_390x286.jpg' WHERE DESCRIPTION = 'HP laptop' AND PRIORITY = 4;

UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/P5P13EA-ABU_1_390x286.jpg' WHERE DESCRIPTION = 'HP Spectre x360 laptop' AND PRIORITY = 1;
UPDATE PRODUCT_IMAGES SET URL = 'http://demo.the-shoal.com/productimages/P5P13EA-ABU_3_390x286.jpg' WHERE DESCRIPTION = 'HP Spectre x360 laptop' AND PRIORITY = 2;

