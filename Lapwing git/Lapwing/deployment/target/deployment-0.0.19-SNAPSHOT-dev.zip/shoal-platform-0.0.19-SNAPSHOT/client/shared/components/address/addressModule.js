/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalCommon.address', []);
}());
