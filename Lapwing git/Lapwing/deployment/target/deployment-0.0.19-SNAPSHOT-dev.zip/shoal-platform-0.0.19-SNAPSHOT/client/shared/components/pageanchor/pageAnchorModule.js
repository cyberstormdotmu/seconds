/*global angular */
(function () {
    'use strict';
    angular.module('shoalCommon.pageAnchor', ['smoothScroll']);
}());
