/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalCommon.frame')
        .directive('shoHeader', function () {
            return {
                restrict: 'A',
                templateUrl: '../shared/components/frame/shoalHeaderView.html',
                replace: true
            };
        });
}());