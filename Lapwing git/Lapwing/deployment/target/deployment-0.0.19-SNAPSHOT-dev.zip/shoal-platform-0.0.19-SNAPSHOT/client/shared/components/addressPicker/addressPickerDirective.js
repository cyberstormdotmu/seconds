/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalCommon.addressPicker')
        .directive('shoAddressPicker', function () {
            return {
                restrict: 'A',
                templateUrl: '../shared/components/addressPicker/addressPickerView.html',
                scope: {},
                bindToController: {
                    selectedAddressKey: '=',
                    selectedAddress: '=',
                    addresses: '='
                },
                controllerAs: 'vm',
                controller: ['$scope', function ($scope) {
                    var vm = this;

                    $scope.$watch(function () {
                        return vm.selectedAddressKey;
                    }, function () {
                        if (vm.selectedAddressKey) {
                            vm.selectedAddress = vm.addresses[vm.selectedAddressKey];
                        } else {
                            vm.selectedAddress = undefined;
                        }
                    });
                }]
            };
        });
}());