/*global angular */
(function () {
    'use strict';
    angular.module('shoalCommon.products', ['ngResource', 'shoalCommon.classes']);
}());
