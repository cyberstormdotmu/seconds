/*global angular */
(function () {
    'use strict';
    angular.module('shoalCommon.classes', []);
}());
