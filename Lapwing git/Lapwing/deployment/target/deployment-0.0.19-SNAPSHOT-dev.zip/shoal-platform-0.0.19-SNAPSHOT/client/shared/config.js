"use strict";

 angular.module('shoal.config', [])

.constant('ENV', {name:'dev',webServiceUrl:'http://localhost:8443/ws',stripeApiKey:'pk_test_zeBbFTBJBmshI2mJ9o93pYQS'})

;