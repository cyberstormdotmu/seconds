/*global angular */
(function () {
    'use strict';
    angular.module('shoalCommon.security', ['ui.router.state']);
}());
