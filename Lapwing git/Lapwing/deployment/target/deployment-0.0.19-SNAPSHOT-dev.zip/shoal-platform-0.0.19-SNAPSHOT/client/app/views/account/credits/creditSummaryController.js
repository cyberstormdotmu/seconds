/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalApp.views.account.credits')
        .controller('shoalApp.views.account.credits.CreditSummaryController', ['$scope', '$http', 'ENV', 'shoalApp_credits_CreditService', function ($scope, $http, ENV, shoalApp_credits_CreditService) {
            var vm = this,
                creditService = shoalApp_credits_CreditService,
                fetchCreditBalances = function () {
                    creditService.getCreditBalances()
                        .then(function (creditBalances) {
                            vm.creditBalances = creditBalances;
                        }, function () {
                            console.log("error reading credit balances");
                        });
                };

            fetchCreditBalances();
        }]);
}());