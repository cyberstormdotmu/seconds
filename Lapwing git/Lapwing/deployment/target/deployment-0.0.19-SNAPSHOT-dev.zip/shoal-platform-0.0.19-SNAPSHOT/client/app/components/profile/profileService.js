/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.profile')
        .factory('shoalApp_profile_ProfileService', ['$rootScope', '$q', 'shoalApp_profile_ProfileResource', function ($rootScope, $q, shoalApp_profile_ProfileResource) {

            var my = {};

            function lockProperties(data) {
                return Object.seal(data);
            }
            function InvalidDataFormatError(message) {
                this.message = message;
            }

            InvalidDataFormatError.prototype = new Error();

            my.profileResource = shoalApp_profile_ProfileResource;
            my.profile = {};
            my.profile.form = {};
            my.saveProfileForm = function () {

                var that = this;
                my.profileResource.save(that, function (response) {
                    console.log("profile form saved");
                    that.isSaved = true;
                    that.isError = false;

                    // rebind form
                    my.profile.form = angular.merge(my.profile.form, response);

                    $rootScope.$broadcast('buyerProfileChange', my.profile);
                }, function () {
                    console.log("profile form save failed");
                    that.isError = true;
                });
                console.log("saving profile form for " + that.organisation.name);
            };

            my.buildProfileForm = function () {
                my.profile.form = {
                    organisation: {
                        name: '',
                        registrationNumber: ''
                    },
                    contact: {
                        title: '',
                        firstName: '',
                        surname: '',
                        emailAddress: '',
                        phoneNumber: ''
                    },
                    deliveryAddress: {
                        departmentName: '',
                        buildingName: '',
                        streetAddress: '',
                        locality: '',
                        postTown: '',
                        postcode: ''
                    },
                    bankAccount: {
                        accountName: '',
                        sortCode: '',
                        accountNumber: '',
                        bankName: '',
                        buildingName: '',
                        streetAddress: '',
                        locality: '',
                        postTown: '',
                        postcode: ''
                    },

                    save: my.saveProfileForm,
                    isSaved: false,
                    isError: false,
                    isCompleted: false,
                    errorMessage: '',
                    $promise: {},
                    $resolved: {}
                };
                console.log('building profile form');
                lockProperties(my.profile.form);
                return my.profile;
            };

            my.fetchBuyerProfile = function () {
                var defer = $q.defer();
                my.profileResource.get(
                    function (response) {
                        my.profile = my.buildProfileForm();
                        try {
                            my.profile.form = angular.merge(my.profile.form, response);
                        } catch (e) {
                            console.log("unable to process response " + JSON.stringify(response));
                            throw new InvalidDataFormatError("data received from server was not in valid format:" + e);
                        }

                        defer.resolve(my.profile);
                    },
                    function (response) {
                        if (response) {
                            defer.reject({
                                reason : response.data.message
                            });
                        } else {
                            defer.reject({
                                reason: 'the server returned an invalid response'
                            });
                        }
                    }
                );
                return defer.promise;
            };

            return Object.create({}, {
                buildProfileForm: {
                    value: function () {
                        return my.buildProfileForm();
                    }
                },
                fetchBuyerProfile: {
                    value: function () {
                        return my.fetchBuyerProfile();
                    }
                }
            });
        }]);
}());
