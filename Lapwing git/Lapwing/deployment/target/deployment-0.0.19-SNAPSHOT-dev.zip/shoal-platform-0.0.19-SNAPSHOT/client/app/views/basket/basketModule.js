/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.views.basket', ['ui.bootstrap', 'shoalApp.basket', 'shoalCommon.products']);
}());
