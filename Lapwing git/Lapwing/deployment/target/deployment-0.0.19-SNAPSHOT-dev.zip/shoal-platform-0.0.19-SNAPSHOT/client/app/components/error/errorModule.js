/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.error', ['shoalCommon.security'])
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('error', {
                    url: '/error',
                    templateUrl: 'views/error/errorView.html',
                    controller: 'shoalApp.views.error.ErrorController',
                    controllerAs: 'vm'
                });
        }]);
}());
