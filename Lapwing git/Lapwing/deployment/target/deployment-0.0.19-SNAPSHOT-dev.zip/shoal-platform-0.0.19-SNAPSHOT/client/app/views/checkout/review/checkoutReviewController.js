/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.checkout')
        .controller('shoalApp.views.checkout.CheckoutReviewController', ['$state', 'shoalApp_checkout_CheckoutService', function ($state, shoalApp_checkout_CheckoutService) {

            var vm = this,
                checkoutService = shoalApp_checkout_CheckoutService,
                init = function () {
                    vm.order = checkoutService.order;
                    vm.paymentCard = checkoutService.paymentCard;
                    vm.order.acceptedTCs = false;
                },
                allowPlaceOrder = function () {
                    return vm.order.acceptedTCs;
                },
                placeOrder = function () {
                    if (vm.order.acceptedTCs) {
                        checkoutService.placeOrder()
                            .then(function (orderReference) {
                                vm.order.orderReference = orderReference;
                                $state.go('checkout.finished');
                            }, function (error) {
                                console.log('unable to complete checkout');
                                vm.errorMessages = [
                                    'Unable to complete the checkout process',
                                    error.reason
                                ];
                            });
                    }
                };

            init();

            vm.placeOrder = placeOrder;
            vm.allowPlaceOrder = allowPlaceOrder;
        }]);
}());