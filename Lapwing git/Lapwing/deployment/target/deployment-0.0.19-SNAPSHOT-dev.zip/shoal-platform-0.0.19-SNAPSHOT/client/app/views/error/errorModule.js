/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.views.error', []);
}());
