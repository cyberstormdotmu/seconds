/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.credits')
        .factory('shoalApp_credits_CreditService', ['$http', '$q', 'ENV', function ($http, $q, ENV) {

            var creditWebServiceUrl = ENV.webServiceUrl + "/credits",

                getCreditBalances = function () {

                    var defer = $q.defer();

                    $http.get(creditWebServiceUrl)
                        .then(function (response) {
                            var creditBalances = response.data;
                            defer.resolve(Object.freeze(creditBalances));
                        }, function (response) {
                            defer.reject(response);
                        });
                    return defer.promise;
                };

            return {
                getCreditBalances: getCreditBalances
            };
        }]);
}());