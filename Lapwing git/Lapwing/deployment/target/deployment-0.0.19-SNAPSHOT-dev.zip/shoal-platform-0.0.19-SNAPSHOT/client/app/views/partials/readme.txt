Partials have no routing and exist only to be nested inside a view.

They are useful in situations where you want to have a single page with multiple steps, or
a page sub-menu that will display different states depending on which button is pressed.