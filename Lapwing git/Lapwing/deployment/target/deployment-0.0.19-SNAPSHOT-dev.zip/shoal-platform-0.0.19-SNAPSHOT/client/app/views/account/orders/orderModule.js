/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.views.account.orders', ['shoalApp.orders']);
}());
