/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.views.partial.profile', ['shoalApp.profile']);
}());
