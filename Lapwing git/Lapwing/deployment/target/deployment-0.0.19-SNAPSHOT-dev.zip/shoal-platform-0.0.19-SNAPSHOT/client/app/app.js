/*global angular, console */
(function () {
    'use strict';

// Declare app level module which depends on views, and components
    angular.module('shoalApp', [
        'ui.router',
        'ngMessages',
        'smoothScroll',
        'shoal.config',
        'shoalCommon.menu',
        'shoalCommon.frame',
        'shoalCommon.pageAnchor',
        'shoalCommon.security',
        'shoalCommon.form',
        'shoalCommon.filters',
        'shoalCommon.formatter',
        'shoalCommon.validator',
        'shoalCommon.classes',
        'shoalApp.views.shopFront',
        'shoalApp.views.product',
        'shoalApp.views.account',
        'shoalApp.views.checkout',
        'shoalApp.views.basket',
        'shoalApp.views.error',
        'shoalApp.views.logout',
        'shoalApp.error'
    ])
        .config(['$urlRouterProvider', '$stateProvider', '$locationProvider', 'shoalCommon_security_LoginRedirectServiceProvider', function ($urlRouterProvider, $stateProvider, $locationProvider, shoalCommon_security_LoginRedirectServiceProvider) {
            $locationProvider.html5Mode(false);
            //$locationProvider.hashPrefix('!');

            $stateProvider.state('home', {
                url: '',
                resolve: {
                    buyerProfile: ['shoalApp_profile_ProfileService', function (shoalApp_profile_ProfileService) {
                        return shoalApp_profile_ProfileService.fetchBuyerProfile();
                    }]
                },
                controller: ['$state', 'buyerProfile', function ($state, buyerProfile) {
                    if (!buyerProfile.form.isCompleted) {
                        $state.go('account.profile');
                    } else {
                        $state.go('shopFront');
                    }
                }]
            });

            shoalCommon_security_LoginRedirectServiceProvider.setLoginPageUri('/public/#/login');
        }])
        .run(['$location', 'shoalCommon_security_RouteChangeService', function redirectBuyerToAccountPageIfTheirProfileIsNotCompleted($location, shoalCommon_security_RouteChangeService) {
            shoalCommon_security_RouteChangeService.handleRouteChange();
        }]);
}());