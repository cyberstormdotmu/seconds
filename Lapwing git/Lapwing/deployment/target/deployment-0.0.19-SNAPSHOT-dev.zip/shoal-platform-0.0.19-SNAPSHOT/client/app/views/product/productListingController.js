/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.product')
        .controller('shoalApp.views.product.ProductListingController', ['$stateParams', 'shoalCommon_products_ProductService', function ($stateParams, shoalCommon_products_ProductService) {
            var vm = this,
                ProductsService = shoalCommon_products_ProductService,
                category = $stateParams.category || 'Products',
                fetchProducts = function () {
                    ProductsService.fetchByTopCategory(category).then(function (products) {
                        vm.products = products;
                    }, function () {
                        console.log("error retrieving product listing");
                    });
                },
                fetchCategory = function () {
                    ProductsService.fetchCategory(category)
                        .then(function (result) {
                            vm.currentCategory = result.name;
                            vm.parentCategories = result.parents;
                        }, function () {
                            console.log("error retrieving category");
                        });
                };

            fetchCategory();
            fetchProducts();
        }]);
}());
