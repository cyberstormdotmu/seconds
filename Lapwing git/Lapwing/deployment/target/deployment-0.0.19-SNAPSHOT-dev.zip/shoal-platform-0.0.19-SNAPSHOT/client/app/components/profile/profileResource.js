/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.profile')
        .factory('shoalApp_profile_ProfileResource', ['$resource', 'ENV', function ($resource, ENV) {

            var my = {};
            my.profileWebServiceUrl = ENV.webServiceUrl + "/profile";
            return $resource(my.profileWebServiceUrl, null,
                {
                    'save': {method: 'PUT'}
                });
        }]);
}());
