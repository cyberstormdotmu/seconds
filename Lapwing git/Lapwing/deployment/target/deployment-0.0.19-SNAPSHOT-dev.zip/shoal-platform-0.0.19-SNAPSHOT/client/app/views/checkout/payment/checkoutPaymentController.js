/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.checkout')
        .controller('shoalApp.views.checkout.CheckoutPaymentController', ['$state', 'shoalApp_checkout_CheckoutService', function ($state, shoalApp_checkout_CheckoutService) {

            var vm = this,
                checkoutService = shoalApp_checkout_CheckoutService,
                init = function () {
                    vm.order = checkoutService.order;
                    vm.order.paymentMethod = 'Card Payment';
                    console.log(JSON.stringify(vm.order));
                    vm.paymentCard = checkoutService.paymentCard;
                    checkoutService.fetchCreditBalances();
                },
                allowNext = function () {
                    return vm.creditSpendForm.$valid && vm.paymentCardForm.$valid;
                },
                next = function () {
                    if (vm.paymentStepForm.$valid) {
                        $state.go('checkout.review');
                    }
                };

            init();

            vm.allowNext = allowNext;
            vm.next = next;

            Object.defineProperty(vm, "availableCreditBalance", {
                get: function () {
                    return checkoutService.availableCreditBalance;
                }
            });

            Object.defineProperty(vm, "maximumCreditSpend", {
                get: function () {
                    return checkoutService.maximumCreditSpend;
                }
            });
        }]);
}());