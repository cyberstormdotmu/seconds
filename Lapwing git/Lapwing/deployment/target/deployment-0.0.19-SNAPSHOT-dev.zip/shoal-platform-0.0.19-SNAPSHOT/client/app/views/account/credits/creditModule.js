/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.views.account.credits', ['shoalApp.credits']);
}());
