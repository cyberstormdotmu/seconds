/*global angular, console */
(function () {
    'use strict';
    function checkoutService($rootScope, $q, shoalApp_classes_Order, shoalApp_orders_OrderService, shoalApp_basket_BasketService, shoalApp_credits_CreditService, shoalApp_payment_PaymentService) {
        var orderService = shoalApp_orders_OrderService,
            basketService = shoalApp_basket_BasketService,
            creditService = shoalApp_credits_CreditService,
            paymentService = shoalApp_payment_PaymentService,
            order,
            paymentCard,
            availableCreditBalance,
            init = function () {
                console.log("checkoutService init");
                paymentService.init();
                paymentCard = paymentService.paymentCard;
                order = shoalApp_classes_Order();
                $rootScope.$on('basketUpdated', function (event, newBasket) {
                    console.log("basketUpdated : " + JSON.stringify(newBasket));
                    if (newBasket) {
                        order.basket = newBasket;
                    }
                });
            },
            fetchCreditBalances = function () {
                creditService.getCreditBalances()
                    .then(function (creditBalances) {
                        availableCreditBalance = creditBalances.availableCreditBalance;
                    }, function () {
                        console.log("error reading credit balances");
                    });
            },
            calculateMaximumCreditSpend = function () {
                if (availableCreditBalance < order.basket.grossTotal) {
                    return availableCreditBalance;
                }
                return order.basket.grossTotal;
            },
            submitOrder = function () {
                var defer = $q.defer();

                orderService.submitOrder(order).then(
                    function (orderSummary) {
                        console.log('order success');
                        basketService.removeAllFromBasket();
                        order.completed = true;
                        defer.resolve(orderSummary.reference);
                    },
                    function (error) {
                        console.log('order failed');
                        defer.reject(error);
                    }
                );

                return defer.promise;
            },
            obtainPaymentToken = function () {
                var defer = $q.defer();

                paymentService.createPaymentCardToken().then(
                    function (paymentCardToken) {
                        defer.resolve(paymentCardToken);
                    },
                    function (error) {
                        defer.reject(error);
                    }
                );

                return defer.promise;
            },
            placeOrder = function () {
                var defer = $q.defer();

                if (order.paymentMethod === "Card Payment") {

                    obtainPaymentToken().then(
                        function (paymentCardToken) {

                            //order.paymentMethod = "Card Payment";
                            order.paymentCardToken = paymentCardToken;
                            defer.resolve(submitOrder());
                        },
                        function (error) {
                            defer.reject(error);
                        }
                    );
                } else {
                    defer.resolve(submitOrder());
                }

                return defer.promise;
            };


        return Object.create({}, {
            init: {
                value: init
            },
            fetchCreditBalances: {
                value: fetchCreditBalances
            },
            order: {
                get: function () {
                    return order;
                }
            },
            paymentCard: {
                get: function () {
                    return paymentCard;
                }
            },
            availableCreditBalance: {
                get: function () {
                    return availableCreditBalance;
                }
            },
            maximumCreditSpend: {
                get: function () {
                    return calculateMaximumCreditSpend();
                }
            },
            placeOrder: {
                value: placeOrder
            }
        });
    }

    angular.module('shoalApp.checkout')
        .factory('shoalApp_checkout_CheckoutService', ['$rootScope', '$q', 'shoalApp_classes_Order',
            'shoalApp_orders_OrderService', 'shoalApp_basket_BasketService',
            'shoalApp_credits_CreditService', 'shoalApp_payment_PaymentService', checkoutService]);
}());