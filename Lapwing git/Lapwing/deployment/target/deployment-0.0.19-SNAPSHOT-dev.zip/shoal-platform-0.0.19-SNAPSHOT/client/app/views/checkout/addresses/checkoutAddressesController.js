/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.checkout')
        .controller('shoalApp.views.checkout.CheckoutAddressesController', ['$state', 'shoalApp_checkout_CheckoutService', 'buyerProfile', function ($state, shoalApp_checkout_CheckoutService,
                                                                            buyerProfile) {

            var vm = this,
                checkoutService = shoalApp_checkout_CheckoutService,
                init = function () {
                    vm.order = checkoutService.order;

                    var buyerAddress = buyerProfile.form.deliveryAddress;
                    buyerAddress.organisationName = buyerProfile.form.organisation.name;

                    vm.addresses = {};
                    vm.addresses[buyerAddress.departmentName] = buyerAddress;

                    vm.deliveryAddressKey = buyerAddress.departmentName;
                    vm.invoiceAddressKey = buyerAddress.departmentName;

                    if (vm.order.deliveryAddress && vm.order.deliveryAddress.departmentName) {
                        vm.deliveryAddressKey = vm.order.deliveryAddress.departmentName;
                    }
                    if (vm.order.invoiceAddress && vm.order.invoiceAddress.departmentName) {
                        vm.invoiceAddressKey = vm.order.invoiceAddress.departmentName;
                    }
                },
                allowNext = function () {
                    return vm.order.invoiceAddress && vm.order.deliveryAddress;
                },
                next = function () {
                    if (vm.addressesStepForm.$valid) {
                        $state.go('checkout.payment');
                    }
                };

            init();

            vm.allowNext = allowNext;
            vm.next = next;
        }]);
}());