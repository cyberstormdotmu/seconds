/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.partial.profile')
        .controller('shoalApp.views.partial.profile.ProfileController', ['userInfo', 'buyerProfile', function (userInfo, buyerProfile) {
            var vm = this;

            vm.userInfo = userInfo;
            vm.profile = buyerProfile;
        }]);
}());