/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalApp.views.shopFront')
        .controller('shoalApp.views.shopFront.ShopFrontController', ['buyerProfile', function (buyerProfile) {
            var vm = this;
            console.log("shopFrontController init" + buyerProfile);
            vm.contact = buyerProfile.form.contact;
        }]);
}());
