/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalApp.views.account.orders')
        .controller('shoalApp.views.account.orders.OrderSummaryController', ['shoalApp_orders_OrderService', function (shoalApp_orders_OrderService) {
            var vm = this,
                ordersService = shoalApp_orders_OrderService,
                fetchOrders = function () {
                    ordersService.getOrders()
                        .then(function (orders) {
                            vm.orders = orders;
                        }, function () {
                            console.log("error reading orders");
                        });
                },
                refresh = function () {
                    fetchOrders();
                };

            fetchOrders();

            vm.refresh = refresh;
        }]);
}());