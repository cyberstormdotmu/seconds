/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.profile', ['ngResource']);
}());
