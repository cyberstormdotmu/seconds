/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.basket', ['ngResource', 'shoalApp.classes', 'shoalCommon.products']);
}());
