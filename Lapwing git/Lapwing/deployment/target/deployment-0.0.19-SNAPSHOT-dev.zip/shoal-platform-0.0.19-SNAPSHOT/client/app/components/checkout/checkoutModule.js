/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.checkout', ['shoalApp.classes', 'shoalApp.payment']);
}());
