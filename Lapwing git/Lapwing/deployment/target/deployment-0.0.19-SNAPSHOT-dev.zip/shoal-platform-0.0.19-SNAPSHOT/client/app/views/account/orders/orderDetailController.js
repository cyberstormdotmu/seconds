/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalApp.views.account.orders')
        .controller('shoalApp.views.account.orders.OrderDetailController', ['$stateParams', 'shoalApp_orders_OrderService', function ($stateParams, shoalApp_orders_OrderService) {
            var vm = this,
                orderReference = $stateParams.orderReference,
                ordersService = shoalApp_orders_OrderService,
                getOrder = function () {
                    ordersService.getOrder(orderReference)
                        .then(function (order) {
                            vm.order = order;
                        }, function () {
                            console.log("error reading order");
                        });
                },
                sumPayments = function () {
                    return vm.order.payments.reduce(function (previousTotal, current) {
                        return previousTotal + current.amount;
                    }, 0);
                },
                sumCredits = function (items, field, filter) {
                    return items.filter(filter).reduce(function (previousTotal, current) {
                        return previousTotal + current.amount[field];
                    }, 0);
                },
                sumCreditsEarned = function (items, field) {
                    return sumCredits(items, field, function (credit) {
                        return credit.creditMovementType === 'Earn';
                    });
                },
                sumCreditsSpent = function (items, field) {
                    return sumCredits(items, field, function (credit) {
                        return credit.creditMovementType !== 'Earn';
                    });
                },
                sumCreditsAvailable = function (items, field) {
                    return sumCredits(items, field, function () {
                        return true;
                    });
                };

            vm.sumCreditsAvailable = sumCreditsAvailable;
            vm.sumCreditsSpent = sumCreditsSpent;
            vm.sumCreditsEarned = sumCreditsEarned;
            vm.sumPayments = sumPayments;

            getOrder();
        }]);
}());