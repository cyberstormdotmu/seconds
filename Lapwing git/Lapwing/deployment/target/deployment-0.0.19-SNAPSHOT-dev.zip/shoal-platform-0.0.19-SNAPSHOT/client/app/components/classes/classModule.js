/*global angular */
(function () {
    'use strict';
    angular.module('shoalApp.classes', []);
}());
