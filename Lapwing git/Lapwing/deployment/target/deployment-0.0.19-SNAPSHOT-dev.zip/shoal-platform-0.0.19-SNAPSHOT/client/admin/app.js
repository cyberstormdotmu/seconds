/*global angular, console */
(function () {
    'use strict';

// Declare app level module which depends on views, and components
    angular.module('shoalAdmin', [
        'ui.router',
        'smoothScroll',
        'ngMessages',
        'shoal.config',
        'shoalCommon.frame',
        'shoalCommon.menu',
        'shoalCommon.form',
        'shoalCommon.pageAnchor',
        'shoalCommon.filters',
        'shoalCommon.classes',
        'shoalAdmin.classes',
        'shoalAdmin.frame',
        'shoalAdmin.orders',
        'shoalAdmin.offers',
        'shoalAdmin.buyers',
        'shoalAdmin.views.menu',
        'shoalAdmin.views.login',
        'shoalAdmin.views.orders',
        'shoalAdmin.views.activeOffers',
        'shoalAdmin.views.registrations',
        'shoalAdmin.views.manageProducts',
        'shoalCommon.validator',
        'ui.bootstrap'
    ])
        .config(['$urlRouterProvider', '$locationProvider', '$httpProvider', 'shoalCommon_security_LoginRedirectServiceProvider', function ($urlRouterProvider, $locationProvider, $httpProvider, shoalCommon_security_LoginRedirectServiceProvider) {

            $urlRouterProvider.otherwise('/login');
            $locationProvider.html5Mode(false);
            //$locationProvider.hashPrefix('!');

            shoalCommon_security_LoginRedirectServiceProvider.setLoginPageUri('/admin/#/login');
        }])
        .run(['shoalCommon_security_RouteChangeService', function (shoalCommon_security_RouteChangeService) {
            shoalCommon_security_RouteChangeService.handleRouteChange();
        }]);
}());