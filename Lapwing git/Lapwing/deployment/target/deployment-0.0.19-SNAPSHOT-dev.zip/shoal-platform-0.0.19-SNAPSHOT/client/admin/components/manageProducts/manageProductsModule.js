/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.manageProducts', ['ngResource', 'shoalCommon.classes']);
}());
