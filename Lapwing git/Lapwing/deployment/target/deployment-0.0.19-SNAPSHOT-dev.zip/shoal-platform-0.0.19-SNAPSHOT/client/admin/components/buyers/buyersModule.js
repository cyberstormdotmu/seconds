/*global angular */
(function () {
    'use strict';
    angular.module('shoalAdmin.buyers', ['ngResource', 'shoalAdmin.classes']);
}());
