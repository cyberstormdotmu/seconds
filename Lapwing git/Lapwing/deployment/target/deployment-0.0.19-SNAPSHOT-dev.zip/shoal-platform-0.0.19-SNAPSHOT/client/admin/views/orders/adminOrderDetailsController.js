/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.views.orders')
        .controller('shoalAdmin.views.orders.AdminOrderDetailsController', ['Notification', 'shoalAdmin_classes_Order', 'shoalAdmin_orders_OrderService', '$uibModal', '$stateParams', function (Notification, shoalAdmin_classes_Order, shoalAdmin_orders_OrderService, $uibModal, $stateParams) {
            var vm = this,
                orderAdminService = shoalAdmin_orders_OrderService,
                orderReference = $stateParams.reference,
                fetchOrder = function () {
                    orderAdminService.fetchOrder(orderReference)
                        .then(function (order) {
                            vm.order = shoalAdmin_classes_Order(order);
                        }, function (failure) {
                            Notification.error({message: failure.reason, delay: 30000});
                        });
                },
                confirmOrder = function () {
                    console.log("confirm order requested for order reference " + orderReference);
                    orderAdminService.confirmOrder(orderReference, vm.order.version)
                        .then(function () {
                            Notification.success('Order confirmed successfully!', {
                                delay: 30000
                            });
                            fetchOrder();
                        }, function (failure) {
                            Notification.error({message: failure.reason, delay: 30000});
                        });
                },
                cancelOrder = function () {
                    console.log("cancel order requested for order reference " + orderReference);
                    orderAdminService.cancelOrder(orderReference, vm.order.version)
                        .then(function () {
                            Notification.success('Order cancelled successfully!', {
                                delay: 30000
                            });
                            fetchOrder();
                        }, function (failure) {
                            Notification.error({message: failure.reason, delay: 30000});
                        });
                },
                recordPayment = function () {
                    var modalInstance = $uibModal.open({
                        templateUrl: 'views/orders/adminOrderPaymentView.html',
                        controller: 'shoalAdmin.views.orders.AdminOrderPaymentController as vm',
                        size: 'lg',
                        resolve: {
                            unpaidAmount: vm.order.summary.unpaidAmount
                        }
                    });

                    modalInstance.result.then(function (paymentDetails) {
                        orderAdminService.recordPayment(orderReference, vm.order.version, paymentDetails)
                            .then(function () {
                                Notification.success('Payment recorded successfully!', {
                                    delay: 30000
                                });
                                fetchOrder();
                            }, function (failure) {
                                Notification.error({message: failure.reason, delay: 30000});
                            });
                    });
                },
                deletePayment = function (paymentReference) {
                    console.log("delete payment requested for order reference and payment reference " + orderReference, paymentReference);
                    orderAdminService.deletePayment(orderReference, vm.order.version, paymentReference)
                        .then(function () {
                            Notification.success('Order payment deleted successfully!', {
                                delay: 30000
                            });
                            fetchOrder();
                        }, function (failure) {
                            Notification.error({message: failure.reason, delay: 30000});
                        });
                },
                sumCredits = function (items, field, filter) {
                    return items.filter(filter).reduce(function (previousTotal, current) {
                        return previousTotal + current.amount[field];
                    }, 0);
                },
                sumCreditsEarned = function (items, field) {
                    return sumCredits(items, field, function (credit) {
                        return credit.creditMovementType === 'Earn';
                    });
                },
                sumCreditsSpent = function (items, field) {
                    return sumCredits(items, field, function (credit) {
                        return credit.creditMovementType !== 'Earn';
                    });
                },
                sumCreditsAvailable = function (items, field) {
                    return sumCredits(items, field, function () {
                        return true;
                    });
                };

            vm.panels = {
                buyerPanelOpen: true,
                linesPanelOpen: true,
                paymentsPanelOpen: true
            };
            vm.sumCreditsAvailable = sumCreditsAvailable;
            vm.sumCreditsSpent = sumCreditsSpent;
            vm.sumCreditsEarned = sumCreditsEarned;
            vm.deletePayment = deletePayment;
            vm.recordPayment = recordPayment;
            vm.cancelOrder = cancelOrder;
            vm.confirmOrder = confirmOrder;

            fetchOrder();
        }]);
}());