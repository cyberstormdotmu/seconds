/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.views.activeOffers')
        .controller('shoalAdmin.views.activeOffers.AdminOfferDetailsController', ['$scope', 'Notification', 'shoalAdmin_offers_OfferService', '$uibModal', '$stateParams', function ($scope, Notification, shoalAdmin_offers_OfferService, $uibModal, $stateParams) {
            var vm = this,
                offerService = shoalAdmin_offers_OfferService,
                offerReference = $stateParams.reference,
                fetchOfferReport = function () {
                    offerService.fetchOfferReport(offerReference)
                        .then(function (report) {
                            vm.report = report;
                        }, function (failure) {
                            Notification.error({message: failure.reason, delay: 30000});
                        });
                };

            fetchOfferReport();
        }]);
}());