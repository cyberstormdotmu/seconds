/*global angular */
(function () {
    'use strict';

    angular.module('shoalAdmin.offers')
        .factory('shoalAdmin_offers_OfferService', ['$http', '$q', 'ENV', function ($http, $q, ENV) {

            var offerAdminWebServiceUrl = ENV.webServiceUrl + "/admin/offers/",

                fetchOffers = function () {
                    var defer = $q.defer();

                    $http.get(offerAdminWebServiceUrl)
                        .then(function (response) {
                            var offers = response.data;
                            defer.resolve(Object.freeze(offers));
                        }, function (response) {
                            defer.reject(response);
                        });
                    return defer.promise;
                },
                fetchOfferReport = function (offerReference) {
                    var defer = $q.defer();

                    $http.get(offerAdminWebServiceUrl + offerReference + '/report')
                        .then(function (response) {
                            var report = response.data;
                            defer.resolve(Object.freeze(report));
                        }, function (response) {
                            defer.reject({
                                reason : response.data.message
                            });
                        });
                    return defer.promise;
                };

            return {
                fetchOffers: fetchOffers,
                fetchOfferReport: fetchOfferReport
            };
        }]);
}());