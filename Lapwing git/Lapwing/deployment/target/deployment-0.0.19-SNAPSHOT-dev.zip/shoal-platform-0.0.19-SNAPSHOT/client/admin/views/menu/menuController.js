/*global angular */
(function () {
    'use strict';
    angular.module('shoalAdmin.views.menu')
        .controller('shoalAdmin.views.menu.NavBarController', function () {
            this.menuItems = [
                {
                    name: 'Orders',
                    state: 'orders'
                },
                {
                    name: 'Active Offers',
                    state: 'activeOffers'
                },
                {
                    name: 'New Registrations',
                    state: 'registrations'
                },
                {
                    name: 'Manage Products',
                    state: 'manageProducts'
                }
            ];
            this.rightMenuItems = [
                {
                    name: 'Logout',
                    state: 'logout'
                }
            ];
        })
        .controller('shoalApp.views.menu.HeaderMenuController', function () {
            this.menuItems = [];
        });
}());