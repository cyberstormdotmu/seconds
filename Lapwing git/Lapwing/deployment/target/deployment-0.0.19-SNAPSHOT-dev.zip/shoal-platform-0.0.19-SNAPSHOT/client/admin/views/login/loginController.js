/*global angular */

(function () {
    'use strict';
    angular.module('shoalAdmin.views.login')
        .controller('shoalAdmin.views.login.LoginController', ['$scope', '$location', 'shoalCommon_security_AuthService', function ($scope, $location, shoalCommon_security_AuthService) {

            var Auth = shoalCommon_security_AuthService;

            Auth.clearCurrentUser();
            $scope.currentUser = Auth.getCurrentUser();

            $scope.login = function () {
                Auth.attemptLogin()
                    .then(function () {
                        $location.path('/orders');
                    });
            };
        }]);
}());