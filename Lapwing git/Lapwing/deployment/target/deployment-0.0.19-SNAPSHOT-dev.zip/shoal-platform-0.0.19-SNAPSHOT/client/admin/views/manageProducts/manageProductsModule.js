/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.views.manageProducts', ['ui.router',
            'ui.bootstrap',
            'shoalAdmin.manageProducts',
            'shoalCommon.products',
            'shoalCommon.vendors',
            'shoalCommon.vatRate'
        ])
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('loggedIn.manageProducts', {
                    url: '/manageProducts/',
                    template: '<ui-view/>',
                    redirectTo: 'loggedIn.manageProducts.create',
                    data: {
                        access: {
                            requiresAuthorisation: true
                            // specify permissions here
                            //requirePermissions: ['User']
                            //permissionType: 'AtLeastOne'
                        }
                    }
                })
                .state('loggedIn.manageProducts.create', {
                    url: '',
                    templateUrl: 'views/manageProducts/createProductView.html',
                    controller: 'shoalAdmin.views.manageProducts.CreateProductController',
                    controllerAs: 'vm',
                    resolve: {
                        productForm: ['shoalAdmin_manageProducts_ManageProductsService', function (shoalAdmin_manageProducts_ManageProductsService) {
                            console.log("resolving productForm");
                            return shoalAdmin_manageProducts_ManageProductsService.buildProduct();
                        }]
                    }
                });
        }]);
}());
