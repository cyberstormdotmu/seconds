/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalAdmin.views.registrations')
        .controller('shoalAdmin.views.registrations.RegistrationsController', ['newRegistrations', function (newRegistrations) {
            var vm = this;
            vm.newRegistrations = newRegistrations;
        }]);
}());
