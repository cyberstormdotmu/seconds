/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalAdmin.views.manageProducts')
        .controller('shoalAdmin.views.manageProducts.CreateProductController', ['$scope', 'productForm', function ($scope, productForm) {
            var vm = this,
                startDate = new Date(),
                endDate = new Date(),
                datePickerOptions = {
                    formatYear: 'yy',
                    startingDay: 1,
                    showWeeks: false,
                    closeOnDateSelection: true
                };

            startDate.setHours(0, 0, 0, 0);
            console.log("init shoalAdmin.views.manageProducts.CreateProductController");
            vm.productForm = productForm;
            vm.startDatePicker = {
                options: datePickerOptions,
                minDate: startDate,
                opened: false
            };
            vm.endDatePicker = {
                options: datePickerOptions,
                minDate: endDate,
                opened: false
            };
            vm.openStartDatePicker = function () {
                vm.startDatePicker.opened = !vm.startDatePicker.opened;
            };
            vm.openEndDatePicker = function () {
                vm.endDatePicker.opened = !vm.endDatePicker.opened;
            };

            // update the min allowed date when the start date changes
            $scope.$watch(function () {
                return vm.productForm.offerStartDate;
            }, function (newValue, oldValue) {
                if (newValue) {
                    console.log("offer start date changed");
                    vm.endDatePicker.minDate = newValue;
                }
            });
        }]);
}());