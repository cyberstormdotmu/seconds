/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.buyers')
        .factory('shoalAdmin_buyers_buyersResource', ['$resource', 'ENV', function ($resource, ENV) {

            var buyerAdminServiceUrl = ENV.webServiceUrl + "/admin/buyers";

            return $resource(buyerAdminServiceUrl, null,
                {
                    "activateBuyer": {url: buyerAdminServiceUrl + '/:id/activateBuyer', method: 'PUT'},
                    'fetchInactiveBuyers': {method: 'GET', params: {role: 'INACTIVE'}}
                });
        }]);
}());
