/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.manageProducts')
        .factory('shoalAdmin_manageProducts_ProductsResource', ['$resource', 'ENV', function ($resource, ENV) {

            var my = {};
            my.adminManageProductsWebServiceUrl = ENV.webServiceUrl + "/admin/manageProducts";
            return $resource(my.adminManageProductsWebServiceUrl, null,
                {
                    'save': {method: 'POST'}
                });
        }]);
}());
