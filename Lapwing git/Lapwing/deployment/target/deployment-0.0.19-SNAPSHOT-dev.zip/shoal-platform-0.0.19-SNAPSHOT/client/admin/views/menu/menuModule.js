/*global angular */
(function () {
    'use strict';
    angular.module('shoalAdmin.views.menu', []);
}());
