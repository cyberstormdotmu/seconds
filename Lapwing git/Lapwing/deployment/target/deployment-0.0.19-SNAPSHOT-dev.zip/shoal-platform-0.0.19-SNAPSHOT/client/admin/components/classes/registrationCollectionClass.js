/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.classes').factory('shoalAdmin_classes_RegistrationCollection', function () {

        // using douglas crockford's functional constructor pattern
        return function initRegistrationCollectionClass(spec, my) {
            console.log("initialising registration collection class");
            var that;
            my = my || {};

            my.registrations = [];
            my.buildRegistration = function () {
                return {
                    buyer: {
                        firstName: '',
                        surname: '',
                        emailAddress: ''
                    },
                    organisation: {
                        name: '',
                        registrationNumber: ''
                    },
                    registeredDate: ''
                };
            };

            that = Object.create({});
            that.refresh = function (afterRefresh) {
                my.refresh(my, afterRefresh);
            };
            that.authorise = function (registration) {
                my.authorise(registration.buyer, function afterAuthorisation() {
                    console.log("buyer was activated");
                    that.refresh();
                });
            };
            // bindable
            Object.defineProperty(that, "registrations", {
                get: function () {
                    return my.registrations;
                }
            });
            return that;

        };
    });
}());
