/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalAdmin.manageProducts')
        .factory('shoalAdmin_manageProducts_ManageProductsService', ['$rootScope', '$q', 'shoalAdmin_manageProducts_ProductsResource', 'shoalCommon_classes_ProductOffer', function ($rootScope, $q, shoalAdmin_manageProducts_ProductsResource,
            shoalCommon_classes_ProductOffer) {

            var my = {};

            function lockProperties(data) {
                return Object.seal(data);
            }
            function InvalidDataFormatError(message) {
                this.message = message;
            }

            InvalidDataFormatError.prototype = new Error();

            my.productResource = shoalAdmin_manageProducts_ProductsResource;
            my.productClass = shoalCommon_classes_ProductOffer;
            my.product = {};
            my.saveProduct = function () {
                console.log("saving product form");
                my.productResource.save(my.product.getProduct(), function (response) {
                    console.log("product form saved");
                    my.product.status.isSaved = true;
                    my.product.status.isError = false;

                    // rebind form
                    //my.product = angular.merge(my.product, response);
                }, function (error) {
                    console.log("product form save failed : " + JSON.stringify(error));
                    my.product.status.isSaved = false;
                    my.product.status.isError = true;
                    if (error.data) {
                        my.product.status.errorMessage = error.data.message;
                    }
                });
            };

            my.buildProduct = function () {
                my.product = my.productClass();
                my.product.specifications.addItem();
                my.product.categories.push('');
                my.product.images.addItem();
                my.product.priceBands.addItem();
                my.product.save = my.saveProduct;
                my.product.status = {
                    isSaved: false,
                    isError: false,
                    errorMessage: ''
                };
                console.log('building product form');
                lockProperties(my.product);
                return my.product;
            };
            return Object.create({}, {
                buildProduct: {
                    value: my.buildProduct
                },
                fetchProductCategories: {
                    value: my.fetchProductCategories
                }
            });
        }]);
}());
