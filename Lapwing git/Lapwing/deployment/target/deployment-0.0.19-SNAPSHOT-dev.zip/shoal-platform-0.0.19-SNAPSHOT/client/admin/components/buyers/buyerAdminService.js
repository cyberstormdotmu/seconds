/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalAdmin.buyers')
        .factory('shoalAdmin_buyers_BuyerAdminService', ['$q', 'shoalAdmin_buyers_buyersResource', 'shoalAdmin_classes_RegistrationCollection', function ($q, shoalAdmin_buyers_buyersResource, shoalAdmin_classes_RegistrationCollection) {
            var my = {},
                that = {},
                registrationCollectionConstructor = shoalAdmin_classes_RegistrationCollection;

            function setReadOnly(data) {
                return Object.freeze(data);
            }

            function InvalidDataFormatError(message) {
                this.message = message;
            }

            InvalidDataFormatError.prototype = new Error();

            my.profileResource = shoalAdmin_buyers_buyersResource;
            my.authorise = function (buyer, afterAuthorisation) {
                my.profileResource.activateBuyer({
                    id: buyer.emailAddress
                }, null, afterAuthorisation);
            };
            my.refresh = function (data, afterRefresh) {
                my.profileResource.fetchInactiveBuyers(function (response) {
                    console.log("fetched all inactive buyers" + JSON.stringify(data));

                    if (response.registrations) {
                        data.registrations = []; // wipe old data
                        try {
                            response.registrations.forEach(function (value) {
                                data.registrations.push(
                                    angular.merge(my.buildRegistration(), value)
                                );
                            });
                        } catch (e) {
                            console.log("unable to process response " + JSON.stringify(response));
                            throw new InvalidDataFormatError("data received from server was not in valid format:" + e);
                        }
                    }
                    if (afterRefresh) {
                        afterRefresh(data);
                    }
                });
            };

            that.fetchUnauthorisedBuyers = function () {
                var defer = $q.defer(),
                    registrationCollection = registrationCollectionConstructor({}, my);

                registrationCollection.refresh(function afterCreated() {
                    console.log("updating client with refreshed registered buyers: " + JSON.stringify(registrationCollection));
                    setReadOnly(registrationCollection.registrations);
                    defer.resolve(registrationCollection);
                });
                return defer.promise;
            };

            return that;
        }]);
}());
