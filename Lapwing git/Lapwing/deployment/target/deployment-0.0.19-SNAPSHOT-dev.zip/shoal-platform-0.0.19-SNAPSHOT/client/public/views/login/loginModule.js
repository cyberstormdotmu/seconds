/*global angular */
(function () {
    'use strict';
    angular.module('shoalPublic.views.login', ['ui.router', 'ui.bootstrap', 'shoalCommon.security', 'shoalCommon.validator']);
}());
