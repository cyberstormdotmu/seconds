/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalPublic.contact')
        .factory('shoalPublic_contact_ContactService', ['$q', '$http', 'ENV', function ($q, $http, ENV) {

            var contactWebServiceUrl = ENV.webServiceUrl + "/contact",
                submitContactRequest = function (contactRequest) {
                    var defer = $q.defer();

                    $http.post(contactWebServiceUrl, contactRequest)
                        .then(function () {
                            defer.resolve();
                        }, function () {
                            defer.reject();
                        });

                    return defer.promise;
                };

            return {
                submitContactRequest: submitContactRequest
            };
        }]);
}());