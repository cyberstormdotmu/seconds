/*global angular, console */
(function () {
    'use strict';
    /* Improvements : We can add a spinner on the login screen if a response takes longer than 250ms
     We can register an event here with Auth.onAuthorised(fn {})
     */
    angular.module('shoalPublic.views.login')
        .controller('shoalPublic.views.login.LoginController', ['$window', '$scope', '$state', '$stateParams', 'shoalCommon_security_AuthService', '$uibModalInstance', function ($window, $scope, $state, $stateParams, shoalCommon_security_AuthService, $uibModalInstance) {
            var vm = this,
                Auth = shoalCommon_security_AuthService,
                login = function () {
                    Auth.attemptLogin()
                        .then(function () {
                            vm.error = undefined;
                            $window.location.replace('/app');
                        }, function (error) {
                            vm.error = error.reason;
                        });
                },
                close = function () {
                    $uibModalInstance.dismiss();
                },
                register = function () {
                    $uibModalInstance.dismiss();
                    $state.go('registration');
                },
                forgottenPassword = function () {
                    $uibModalInstance.dismiss();
                    $state.go('passwordreset');
                };

            Auth.clearCurrentUser();

            vm.currentUser = Auth.getCurrentUser();
            vm.login = login;
            vm.close = close;
            vm.register = register;
            vm.forgottenPassword = forgottenPassword;
            vm.loggedOut = !!$stateParams.logout;
        }]);
}());