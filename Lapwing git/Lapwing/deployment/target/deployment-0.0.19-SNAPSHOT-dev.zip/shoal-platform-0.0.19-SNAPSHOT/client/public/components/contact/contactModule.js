/*global angular */
(function () {
    'use strict';
    angular.module('shoalPublic.contact', ['ngResource']);
}());
