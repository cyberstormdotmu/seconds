/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalPublic.views.home')
        .controller('shoalPublic.views.home.HomeController', ['$state', 'shoalPublic_views_login_LoginViewModal', function ($state, shoalPublic_views_login_LoginViewModal) {
            var vm = this,
                loginModal = shoalPublic_views_login_LoginViewModal,
                openLoginModal = function () {
                    console.log('open login modal');
                    loginModal.show();
                };

            vm.openLoginModal = openLoginModal;
        }]);
}());