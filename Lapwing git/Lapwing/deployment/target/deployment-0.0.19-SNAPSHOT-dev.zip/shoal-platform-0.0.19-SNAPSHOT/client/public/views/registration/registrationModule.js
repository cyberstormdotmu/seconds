/*global angular */
(function () {
    'use strict';
    angular.module('shoalPublic.views.registration', ['ui.router.state', 'shoalPublic.registration', 'shoalCommon.validator'])
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('registration', {
                    url: '/registration',
                    templateUrl: '/public/views/registration/registrationView.html',
                    controller: 'shoalPublic.views.registration.RegistrationController',
                    controllerAs: 'vm',
                    resolve: {
                        registrationForm: ['shoalPublic_registration_RegistrationService', function (shoalPublic_registration_RegistrationService) {
                            return shoalPublic_registration_RegistrationService.buildRegistrationForm();
                        }]
                    }
                });
        }]);
}());
