/*global angular, console */
(function () {
    'use strict';
    angular.module('shoalPublic.registration')
        .factory('shoalPublic_registration_RegistrationService', ['$q', 'shoalPublic_registration_RegistrationResource', function ($q, shoalPublic_registration_RegistrationResource) {

            var my = {};

            my.registrationResource = shoalPublic_registration_RegistrationResource;

            my.saveRegistrationForm = function () {
                var that = this,
                    defer = $q.defer();

                my.registrationResource.save(that, function () {
                    console.log("registration form saved");
                    that.isSaved = true;
                    that.isError = false;
                    defer.resolve();
                }, function (response) {
                    console.log("registration form save failed");
                    that.isError = true;
                    that.errorMessage = response.data.message;
                    defer.reject();
                });
                console.log("saving registration form for " + that.buyer.emailAddress);
                return defer.promise;
            };
            my.buildRegistrationForm = function () {
                var form = {
                    buyer: {
                        firstName: '',
                        surname: '',
                        emailAddress: '',
                        password: ''
                    },
                    organisation: {
                        name: '',
                        registrationNumber: ''
                    },
                    save: my.saveRegistrationForm,
                    isSaved: false,
                    isError: false,
                    errorMessage: ''
                };
                console.log('building registration form');
                return Object.seal(form);
            };

            return Object.create({}, {
                buildRegistrationForm: {
                    value: function () {
                        return my.buildRegistrationForm();
                    }
                }
            });
        }]);
}());