/*global angular, console */
(function () {
    'use strict';

    angular.module('shoalPublic.views.registration')
        .controller('shoalPublic.views.registration.RegistrationController', ['$location', 'registrationForm', function ($location, registrationForm) {
            var vm = this;
            vm.registrationForm = registrationForm;
            vm.saving = false;

            vm.save = function () {
                if (!vm.saving) {
                    vm.saving = true;
                    this.registrationForm.save()
                        .then(function () {
                            vm.saving = false;
                        });
                }
            };
        }]);
}());