-- drop this user as i'd rather use the service api to create users for testing as it's less maintenance work
-- peter@ppb.com
DELETE FROM users WHERE user_name = 'peter@ppb.com';
DELETE FROM organisations WHERE name = 'Pawtucket Patriot Brewery';

