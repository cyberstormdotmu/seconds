"use strict";

 angular.module('shoal.config', [])

.constant('ENV', {name:'demo',webServiceUrl:'https://demo.the-shoal.com/ws',stripeApiKey:'pk_test_zeBbFTBJBmshI2mJ9o93pYQS'})

;