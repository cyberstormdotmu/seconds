"use strict";

 angular.module('shoal.config', [])

.constant('ENV', {name:'ci',webServiceUrl:'https://localhost/ws',stripeApiKey:'pk_test_zeBbFTBJBmshI2mJ9o93pYQS'})

;