This is a common directory for all shoal client apps.

Only services and directives should be placed in here as these are reusable components in the angular world.

Absolutely no controllers / views are allowed in here, ever !

If you want to share code between applications, put it in a service.

If you want to share web parts between applications, put it in a directive.

If you want to share layout between applications, put it in css.